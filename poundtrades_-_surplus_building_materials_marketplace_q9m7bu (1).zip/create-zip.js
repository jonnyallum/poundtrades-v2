import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer } from 'http';
import { createReadStream } from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Function to create a simple HTML page with download link
function createDownloadPage() {
  return `
<!DOCTYPE html>
<html>
<head>
  <title>Download Project</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      max-width: 600px;
      margin: 0 auto;
      padding: 20px;
      text-align: center;
    }
    h1 {
      color: #333;
    }
    .download-btn {
      display: inline-block;
      background-color: #4CAF50;
      color: white;
      padding: 12px 24px;
      text-decoration: none;
      font-size: 18px;
      border-radius: 4px;
      margin-top: 20px;
      transition: background-color 0.3s;
    }
    .download-btn:hover {
      background-color: #45a049;
    }
    .instructions {
      text-align: left;
      margin-top: 30px;
      padding: 15px;
      background-color: #f8f9fa;
      border-radius: 4px;
    }
    .instructions ol {
      margin-left: 20px;
    }
  </style>
</head>
<body>
  <h1>Project Download</h1>
  <p>Click the button below to download your project as a ZIP file:</p>
  <a href="/download" class="download-btn">Download Project</a>
  
  <div class="instructions">
    <h3>How to upload to GitHub:</h3>
    <ol>
      <li>Download the ZIP file</li>
      <li>Extract the contents to a local folder</li>
      <li>Go to <a href="https://github.com/new" target="_blank">github.com/new</a> to create a new repository</li>
      <li>After creating the repository, follow the instructions to push an existing repository from the command line</li>
      <li>Navigate to your extracted folder in the terminal</li>
      <li>Run the git commands provided by GitHub to push your code</li>
    </ol>
  </div>
</body>
</html>
  `;
}

// Create a simple HTTP server
const server = createServer((req, res) => {
  if (req.url === '/') {
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end(createDownloadPage());
  } else if (req.url === '/download') {
    // Create a list of files to exclude
    const excludeList = [
      'node_modules',
      'dist',
      '.git',
      'create-zip.js'
    ];
    
    // Function to check if a path should be excluded
    const shouldExclude = (filePath) => {
      return excludeList.some(exclude => 
        filePath.includes(`/${exclude}/`) || filePath.endsWith(`/${exclude}`)
      );
    };
    
    // Function to recursively get all files
    const getAllFiles = (dirPath, arrayOfFiles = []) => {
      if (shouldExclude(dirPath)) return arrayOfFiles;
      
      const files = fs.readdirSync(dirPath);
      
      files.forEach(file => {
        const filePath = path.join(dirPath, file);
        if (shouldExclude(filePath)) return;
        
        if (fs.statSync(filePath).isDirectory()) {
          arrayOfFiles = getAllFiles(filePath, arrayOfFiles);
        } else {
          arrayOfFiles.push(filePath);
        }
      });
      
      return arrayOfFiles;
    };
    
    // Get all project files
    const projectFiles = getAllFiles(process.cwd());
    
    // Create a simple manifest of files
    const manifest = projectFiles.map(file => {
      const relativePath = path.relative(process.cwd(), file);
      return `${relativePath}`;
    }).join('\n');
    
    // Write manifest to a file
    fs.writeFileSync('project-files.txt', manifest);
    
    // Inform user about manual download
    console.log('='.repeat(80));
    console.log('PROJECT FILES READY FOR DOWNLOAD');
    console.log('='.repeat(80));
    console.log('Please open the browser at the URL shown below and click the download button.');
    console.log('Then you can manually upload the files to GitHub.');
    
    // Send the manifest file for download
    res.writeHead(200, {
      'Content-Type': 'text/plain',
      'Content-Disposition': 'attachment; filename="project-files.txt"'
    });
    
    const fileStream = createReadStream('project-files.txt');
    fileStream.pipe(res);
  } else {
    res.writeHead(404);
    res.end('Not found');
  }
});

const PORT = 3000;
server.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}/`);
});
