import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Predefined repository URL
const repoUrl = 'https://github.com/jonnyallum/Poundtrades.co.uk.git';

// Function to execute shell commands
function runCommand(command) {
  try {
    console.log(`Executing: ${command}`);
    const output = execSync(command, { encoding: 'utf8' });
    return output;
  } catch (error) {
    console.error(`Error executing command: ${command}`);
    console.error(error.message);
    process.exit(1);
  }
}

// Main function to handle GitHub push
async function pushToGitHub() {
  // Check if .git directory exists
  const isGitRepo = fs.existsSync(path.join(process.cwd(), '.git'));
  
  if (!isGitRepo) {
    console.log('Initializing Git repository...');
    runCommand('git init');
  }
  
  // Add all files to git
  console.log('Adding files to git...');
  runCommand('git add .');
  
  // Commit changes
  console.log('Committing changes...');
  runCommand('git commit -m "Enhanced components with more context and visual depth"');
  
  // Check if remote origin exists
  let remoteExists = false;
  try {
    const remotes = runCommand('git remote -v');
    remoteExists = remotes.includes('origin');
  } catch (error) {
    // No remotes exist
  }
  
  // Add remote if it doesn't exist
  if (!remoteExists) {
    console.log('Adding remote origin...');
    runCommand(`git remote add origin ${repoUrl}`);
  } else {
    // Update remote if it exists but with a different URL
    console.log('Updating remote origin...');
    runCommand(`git remote set-url origin ${repoUrl}`);
  }
  
  // Push to GitHub
  console.log('Pushing to GitHub...');
  try {
    runCommand('git push -u origin master');
  } catch (error) {
    // Try main branch if master fails
    try {
      runCommand('git push -u origin main');
    } catch (mainError) {
      console.log('Failed to push to master or main branch.');
      console.log('Creating a new branch and pushing...');
      runCommand('git checkout -b main');
      runCommand('git push -u origin main');
    }
  }
  
  console.log(`\nSuccessfully pushed to ${repoUrl}`);
}

// Run the main function
pushToGitHub();
