export interface Category {
  id: string;
  name: string;
  icon: string;
  description: string;
}

export interface Service {
  id: string;
  name: string;
  icon: string;
  description: string;
  location?: {
    lat: number;
    lng: number;
  };
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  company: string;
  content: string;
  avatar: string;
}

export interface Feature {
  id: string;
  title: string;
  description: string;
  icon: string;
}

export interface MapLocation {
  id: string;
  name: string;
  type: string;
  location: {
    lat: number;
    lng: number;
  };
}
