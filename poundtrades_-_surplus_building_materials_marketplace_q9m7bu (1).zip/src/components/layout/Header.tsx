import React, { useState } from 'react';
import { Menu, X, Search, User, ShoppingCart } from 'lucide-react';
import Button from '../ui/Button';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center">
            <a href="/" className="flex items-center">
              <span className="text-2xl font-bold text-[#1a1a1a]">
                Pound<span className="text-[#f7d046]">Trades</span>
              </span>
            </a>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#" className="text-gray-700 hover:text-[#f7d046] font-medium">
              Home
            </a>
            <a href="#" className="text-gray-700 hover:text-[#f7d046] font-medium">
              Categories
            </a>
            <a href="#" className="text-gray-700 hover:text-[#f7d046] font-medium">
              Services
            </a>
            <a href="#" className="text-gray-700 hover:text-[#f7d046] font-medium">
              About
            </a>
            <a href="#" className="text-gray-700 hover:text-[#f7d046] font-medium">
              Contact
            </a>
          </nav>

          {/* Actions */}
          <div className="hidden md:flex items-center space-x-4">
            <button className="p-2 text-gray-700 hover:text-[#f7d046]">
              <Search size={20} />
            </button>
            <button className="p-2 text-gray-700 hover:text-[#f7d046]">
              <User size={20} />
            </button>
            <button className="p-2 text-gray-700 hover:text-[#f7d046]">
              <ShoppingCart size={20} />
            </button>
            <Button variant="primary" size="sm">
              Post Listing
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2 text-gray-700"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 pb-4">
            <nav className="flex flex-col space-y-4">
              <a href="#" className="text-gray-700 hover:text-[#f7d046] font-medium">
                Home
              </a>
              <a href="#" className="text-gray-700 hover:text-[#f7d046] font-medium">
                Categories
              </a>
              <a href="#" className="text-gray-700 hover:text-[#f7d046] font-medium">
                Services
              </a>
              <a href="#" className="text-gray-700 hover:text-[#f7d046] font-medium">
                About
              </a>
              <a href="#" className="text-gray-700 hover:text-[#f7d046] font-medium">
                Contact
              </a>
              <div className="flex items-center space-x-4 pt-2">
                <button className="p-2 text-gray-700 hover:text-[#f7d046]">
                  <Search size={20} />
                </button>
                <button className="p-2 text-gray-700 hover:text-[#f7d046]">
                  <User size={20} />
                </button>
                <button className="p-2 text-gray-700 hover:text-[#f7d046]">
                  <ShoppingCart size={20} />
                </button>
              </div>
              <Button variant="primary" size="sm" className="mt-2">
                Post Listing
              </Button>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
