import React from 'react';
import { categories } from '../../data/categories';
import { Square, Tree, Layers, Pipe, Zap, DoorOpen, Home, Tool } from 'lucide-react';

const Categories: React.FC = () => {
  // Map category icons to Lucide components
  const getIcon = (iconName: string, size = 24) => {
    switch (iconName) {
      case 'square':
        return <Square size={size} />;
      case 'tree':
        return <Tree size={size} />;
      case 'layers':
        return <Layers size={size} />;
      case 'pipe':
        return <Pipe size={size} />;
      case 'zap':
        return <Zap size={size} />;
      case 'door':
        return <DoorOpen size={size} />;
      case 'home':
        return <Home size={size} />;
      case 'tool':
        return <Tool size={size} />;
      default:
        return <Square size={size} />;
    }
  };

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Browse Categories</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Explore our wide range of building material categories to find exactly what you need for your next project
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {categories.map((category) => (
            <div 
              key={category.id}
              className="bg-white rounded-lg shadow-md p-6 transition-transform hover:transform hover:scale-105 hover:shadow-lg"
            >
              <div className="text-[#f7d046] mb-4">
                {getIcon(category.icon, 40)}
              </div>
              <h3 className="text-xl font-semibold mb-2">{category.name}</h3>
              <p className="text-gray-600">{category.description}</p>
              <a href="#" className="inline-block mt-4 text-[#1a1a1a] font-medium hover:text-[#f7d046]">
                View listings →
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Categories;
