import React, { useState, useCallback, useMemo } from 'react';
import { GoogleMap, useJsApiLoader, Marker, InfoWindow } from '@react-google-maps/api';
import { mapLocations } from '../../data/services';
import Button from '../ui/Button';

// Using the provided Google Maps API key
const GOOGLE_MAPS_API_KEY = 'ba059b49d6fcb6770ab3d64a69454f2de808a4e4';

const containerStyle = {
  width: '100%',
  height: '400px'
};

const defaultCenter = {
  lat: 51.505,
  lng: -0.09
};

const Map: React.FC = () => {
  const [selectedLocation, setSelectedLocation] = useState<string | null>(null);
  const [mapRef, setMapRef] = useState<google.maps.Map | null>(null);
  const [isApiLoaded, setIsApiLoaded] = useState(false);
  const [activeFilter, setActiveFilter] = useState<string | null>(null);

  const { isLoaded } = useJsApiLoader({
    id: 'google-map-script',
    googleMapsApiKey: GOOGLE_MAPS_API_KEY
  });

  const onLoad = useCallback((map: google.maps.Map) => {
    setMapRef(map);
    setIsApiLoaded(true);
    
    // Fit bounds to show all markers
    if (mapLocations.length > 0) {
      const bounds = new google.maps.LatLngBounds();
      mapLocations.forEach(location => {
        bounds.extend(location.location);
      });
      map.fitBounds(bounds);
    }
  }, []);

  const onUnmount = useCallback(() => {
    setMapRef(null);
    setIsApiLoaded(false);
  }, []);

  const handleMarkerClick = (locationId: string) => {
    setSelectedLocation(locationId);
  };

  const handleInfoWindowClose = () => {
    setSelectedLocation(null);
  };

  const handleFilterClick = (type: string) => {
    setActiveFilter(activeFilter === type ? null : type);
    
    if (mapRef) {
      // If removing filter, show all markers
      if (activeFilter === type) {
        const bounds = new google.maps.LatLngBounds();
        mapLocations.forEach(location => {
          bounds.extend(location.location);
        });
        mapRef.fitBounds(bounds);
      } else {
        // If applying filter, focus on filtered markers
        const filteredLocations = mapLocations.filter(loc => loc.type === type);
        if (filteredLocations.length > 0) {
          const bounds = new google.maps.LatLngBounds();
          filteredLocations.forEach(location => {
            bounds.extend(location.location);
          });
          mapRef.fitBounds(bounds);
        }
      }
    }
  };

  const handleUseCurrentLocation = () => {
    if (navigator.geolocation && mapRef) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const userLocation = {
            lat: position.coords.latitude,
            lng: position.coords.longitude
          };
          
          mapRef.panTo(userLocation);
          mapRef.setZoom(14);
        },
        () => {
          alert('Unable to retrieve your location. Please check your browser settings.');
        }
      );
    } else {
      alert('Geolocation is not supported by your browser.');
    }
  };

  const filteredLocations = useMemo(() => {
    if (!activeFilter) return mapLocations;
    return mapLocations.filter(location => location.type === activeFilter);
  }, [activeFilter]);

  const selectedLocationData = useMemo(() => {
    if (!selectedLocation) return null;
    return mapLocations.find(location => location.id === selectedLocation);
  }, [selectedLocation]);

  const serviceTypes = useMemo(() => {
    return Array.from(new Set(mapLocations.map(loc => loc.type)));
  }, []);

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Find Services Near You</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Browse local services and tradespeople in your area. Our interactive map helps you find the perfect service provider nearby.
          </p>
        </div>
        
        {isLoaded ? (
          <div className="rounded-lg overflow-hidden shadow-lg">
            <GoogleMap
              mapContainerStyle={containerStyle}
              center={defaultCenter}
              zoom={13}
              onLoad={onLoad}
              onUnmount={onUnmount}
              options={{
                streetViewControl: false,
                mapTypeControl: false,
                fullscreenControl: true,
                zoomControl: true,
                styles: [
                  {
                    featureType: 'poi',
                    elementType: 'labels',
                    stylers: [{ visibility: 'off' }]
                  }
                ]
              }}
            >
              {filteredLocations.map((location) => (
                <Marker
                  key={location.id}
                  position={location.location}
                  onClick={() => handleMarkerClick(location.id)}
                  icon={{
                    url: `https://maps.google.com/mapfiles/ms/icons/${getMarkerColor(location.type)}-dot.png`,
                    scaledSize: new window.google.maps.Size(32, 32)
                  }}
                  animation={google.maps.Animation.DROP}
                />
              ))}

              {selectedLocationData && (
                <InfoWindow
                  position={selectedLocationData.location}
                  onCloseClick={handleInfoWindowClose}
                >
                  <div className="p-2">
                    <h3 className="font-bold text-lg">{selectedLocationData.name}</h3>
                    <p className="text-sm text-gray-600 mb-2">Service Provider</p>
                    <div className="flex gap-2">
                      <Button size="sm" variant="primary">View Details</Button>
                      <Button size="sm" variant="outline">Contact</Button>
                    </div>
                  </div>
                </InfoWindow>
              )}
            </GoogleMap>
          </div>
        ) : (
          <div className="bg-gray-200 rounded-lg h-[400px] flex flex-col items-center justify-center">
            <div className="animate-pulse flex space-x-4 mb-4">
              <div className="rounded-full bg-gray-300 h-12 w-12"></div>
              <div className="flex-1 space-y-4 py-1">
                <div className="h-4 bg-gray-300 rounded w-3/4"></div>
                <div className="space-y-2">
                  <div className="h-4 bg-gray-300 rounded"></div>
                  <div className="h-4 bg-gray-300 rounded w-5/6"></div>
                </div>
              </div>
            </div>
            <p className="text-gray-500">Loading map...</p>
          </div>
        )}

        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-gray-50 p-4 rounded-lg shadow">
            <h3 className="font-bold text-lg mb-2">Filter by Service</h3>
            <div className="flex flex-wrap gap-2">
              {serviceTypes.map(type => (
                <Button 
                  key={type} 
                  size="sm" 
                  variant={activeFilter === type ? "primary" : "outline"}
                  className="text-xs"
                  onClick={() => handleFilterClick(type)}
                >
                  {type.charAt(0).toUpperCase() + type.slice(1)}
                </Button>
              ))}
            </div>
          </div>
          
          <div className="bg-gray-50 p-4 rounded-lg shadow">
            <h3 className="font-bold text-lg mb-2">Search Radius</h3>
            <input 
              type="range" 
              min="1" 
              max="50" 
              defaultValue="10" 
              className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
              onChange={(e) => {
                if (mapRef && selectedLocationData) {
                  const radius = parseInt(e.target.value);
                  mapRef.setZoom(14 - Math.log2(radius / 2));
                }
              }}
            />
            <div className="flex justify-between text-sm text-gray-600 mt-1">
              <span>1 mile</span>
              <span>50 miles</span>
            </div>
          </div>
          
          <div className="bg-gray-50 p-4 rounded-lg shadow">
            <h3 className="font-bold text-lg mb-2">Your Location</h3>
            <Button 
              variant="primary" 
              fullWidth 
              className="flex items-center justify-center gap-2"
              onClick={handleUseCurrentLocation}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
              </svg>
              Use Current Location
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

// Helper function to determine marker color based on service type
function getMarkerColor(type: string): string {
  const colorMap: Record<string, string> = {
    builders: 'red',
    carpenters: 'blue',
    electricians: 'yellow',
    plumbers: 'green',
    roofers: 'purple',
    landscapers: 'orange'
  };
  
  return colorMap[type.toLowerCase()] || 'red';
}

export default Map;
