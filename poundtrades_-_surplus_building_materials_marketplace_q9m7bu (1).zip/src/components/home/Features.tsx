import React from 'react';
import { MapPin, PoundSterling, Shield, Truck } from 'lucide-react';

const features = [
  {
    icon: <MapPin className="w-10 h-10 text-gold-500" />,
    title: 'Location-Based Search',
    description: 'Find materials near you with our advanced location search. Save time and transport costs.'
  },
  {
    icon: <PoundSterling className="w-10 h-10 text-gold-500" />,
    title: 'Just £1 Per Contact',
    description: 'Pay only £1 to access seller contact details. No hidden fees or commissions.'
  },
  {
    icon: <Shield className="w-10 h-10 text-gold-500" />,
    title: 'Secure Payments',
    description: 'All transactions are processed securely. Your payment and personal details are protected.'
  },
  {
    icon: <Truck className="w-10 h-10 text-gold-500" />,
    title: 'Delivery Options',
    description: 'Arrange delivery or collection directly with sellers. Flexible options to suit your needs.'
  }
];

const Features: React.FC = () => {
  return (
    <section className="py-16 bg-gray-950">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-white mb-2">Why Choose PoundTrades?</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            We connect buyers and sellers of surplus building materials with a simple, affordable platform
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="bg-gray-900 border border-gray-800 rounded-lg p-6 text-center transition-all duration-300 hover:border-gold-500 hover:shadow-gold"
            >
              <div className="flex justify-center mb-4">
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">{feature.title}</h3>
              <p className="text-gray-400">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
