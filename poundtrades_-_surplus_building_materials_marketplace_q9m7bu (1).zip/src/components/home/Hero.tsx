import React from 'react';
import { Search, MapPin } from 'lucide-react';
import Input from '../ui/Input';
import Button from '../ui/Button';

const Hero: React.FC = () => {
  return (
    <section className="relative bg-[#1a1a1a] text-white">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="w-full h-full" style={{ 
          backgroundImage: "url(\"data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E\")",
          backgroundSize: '60px 60px'
        }}></div>
      </div>
      
      <div className="container mx-auto px-4 py-20 md:py-32 relative z-10">
        <div className="max-w-3xl mx-auto text-center mb-12">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
            Find <span className="text-[#f7d046]">Surplus Building Materials</span> at Unbeatable Prices
          </h1>
          <p className="text-xl text-gray-300 mb-8">
            Connect with local builders and suppliers to buy and sell excess construction materials across the UK
          </p>
          
          {/* Search Form */}
          <div className="bg-white p-4 rounded-lg shadow-lg">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <Input 
                  type="text" 
                  placeholder="What are you looking for?" 
                  icon={<Search size={20} />} 
                />
              </div>
              <div className="flex-1">
                <Input 
                  type="text" 
                  placeholder="Location" 
                  icon={<MapPin size={20} />} 
                />
              </div>
              <Button variant="primary" className="md:w-auto">
                Search
              </Button>
            </div>
          </div>
        </div>
        
        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-12">
          <div className="text-center">
            <p className="text-3xl md:text-4xl font-bold text-[#f7d046]">10,000+</p>
            <p className="text-gray-300">Active Listings</p>
          </div>
          <div className="text-center">
            <p className="text-3xl md:text-4xl font-bold text-[#f7d046]">5,000+</p>
            <p className="text-gray-300">Registered Users</p>
          </div>
          <div className="text-center">
            <p className="text-3xl md:text-4xl font-bold text-[#f7d046]">£2M+</p>
            <p className="text-gray-300">Materials Saved</p>
          </div>
          <div className="text-center">
            <p className="text-3xl md:text-4xl font-bold text-[#f7d046]">500+</p>
            <p className="text-gray-300">UK Locations</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
