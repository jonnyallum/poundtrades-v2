import React, { useState } from 'react';
import { mapLocations } from '../../data/services';
import Button from '../ui/Button';

const MapPreview: React.FC = () => {
  const [selectedLocation, setSelectedLocation] = useState('1');
  const [activeFilter, setActiveFilter] = useState<string | null>(null);
  const [searchRadius, setSearchRadius] = useState(10);
  
  const handleLocationClick = (locationId: string) => {
    setSelectedLocation(locationId);
  };
  
  const handleFilterClick = (type: string) => {
    setActiveFilter(activeFilter === type ? null : type);
  };
  
  const filteredLocations = activeFilter 
    ? mapLocations.filter(loc => loc.type === activeFilter)
    : mapLocations;
    
  const selectedLocationData = mapLocations.find(loc => loc.id === selectedLocation);
  
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Find Services Near You</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Browse local services and tradespeople in your area. Our interactive map helps you find the perfect service provider nearby.
          </p>
        </div>
        
        <div className="rounded-lg overflow-hidden shadow-lg relative">
          {/* Static map preview */}
          <div className="bg-blue-50 h-[500px] relative">
            {/* Map background with grid */}
            <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI0MCIgaGVpZ2h0PSI0MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAwIDEwIEwgNDAgMTAgTSAxMCAwIEwgMTAgNDAgTSAwIDIwIEwgNDAgMjAgTSAyMCAwIEwgMjAgNDAgTSAwIDMwIEwgNDAgMzAgTSAzMCAwIEwgMzAgNDAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzhlYjhmOCIgb3BhY2l0eT0iMC4yIiBzdHJva2Utd2lkdGg9IjEiLz48L3BhdHRlcm4+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZ3JpZCkiLz48L3N2Zz4=')]"></div>
            
            {/* Map features */}
            <div className="absolute inset-0">
              {/* Water features */}
              <div className="absolute top-[20%] left-[10%] w-[25%] h-[30%] bg-blue-200 rounded-full opacity-50"></div>
              
              {/* Parks/green areas */}
              <div className="absolute bottom-[15%] right-[15%] w-[20%] h-[25%] bg-green-200 rounded-lg opacity-60"></div>
              <div className="absolute top-[10%] right-[20%] w-[15%] h-[15%] bg-green-200 rounded-lg opacity-60"></div>
              
              {/* Roads */}
              <div className="absolute top-[50%] left-0 right-0 h-[10px] bg-gray-300"></div>
              <div className="absolute top-0 bottom-0 left-[50%] w-[10px] bg-gray-300"></div>
              <div className="absolute top-[30%] left-[20%] right-0 h-[6px] bg-gray-300"></div>
              <div className="absolute top-0 bottom-0 left-[70%] w-[6px] bg-gray-300"></div>
              <div className="absolute top-[70%] left-[10%] w-[80%] h-[8px] bg-gray-300"></div>
              <div className="absolute top-[10%] left-[30%] h-[80%] w-[8px] bg-gray-300"></div>
              
              {/* Road labels */}
              <div className="absolute top-[48%] left-[5%] transform -translate-y-full">
                <span className="bg-white px-2 py-1 text-xs rounded shadow">Main St</span>
              </div>
              <div className="absolute top-[5%] left-[50%] transform -translate-x-1/2">
                <span className="bg-white px-2 py-1 text-xs rounded shadow">High St</span>
              </div>
              <div className="absolute top-[28%] left-[80%] transform -translate-y-full">
                <span className="bg-white px-2 py-1 text-xs rounded shadow">Park Rd</span>
              </div>
              
              {/* Neighborhoods */}
              <div className="absolute top-[40%] left-[25%] text-gray-400 text-sm font-light">
                Westfield
              </div>
              <div className="absolute top-[60%] right-[25%] text-gray-400 text-sm font-light">
                Eastside
              </div>
              <div className="absolute top-[20%] right-[30%] text-gray-400 text-sm font-light">
                Northpark
              </div>
            </div>
            
            {/* Search radius visualization */}
            <div 
              className="absolute rounded-full border-2 border-blue-400 border-dashed opacity-40"
              style={{
                left: '50%',
                top: '50%',
                width: `${searchRadius * 10}%`,
                height: `${searchRadius * 10}%`,
                transform: 'translate(-50%, -50%)'
              }}
            ></div>
            
            {/* Location markers */}
            {filteredLocations.map((location) => {
              // Calculate position based on relative coordinates
              const left = ((location.location.lng + 0.12) / 0.24) * 100;
              const top = (1 - ((location.location.lat - 51.49) / 0.04)) * 100;
              
              const isSelected = location.id === selectedLocation;
              
              return (
                <div 
                  key={location.id}
                  className={`absolute w-6 h-6 transform -translate-x-1/2 -translate-y-1/2 cursor-pointer transition-all duration-300 ${isSelected ? 'z-10 scale-125' : 'z-0'}`}
                  style={{ 
                    left: `${Math.min(Math.max(left, 5), 95)}%`, 
                    top: `${Math.min(Math.max(top, 5), 95)}%` 
                  }}
                  onClick={() => handleLocationClick(location.id)}
                >
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center ${getMarkerBgColor(location.type)} ${isSelected ? 'ring-2 ring-white shadow-lg' : ''}`}>
                    <span className="text-white text-xs font-bold">{location.name.charAt(0)}</span>
                  </div>
                  <div className={`absolute -bottom-1 left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-[6px] border-l-transparent border-r-[6px] border-r-transparent border-t-[6px] ${isSelected ? 'opacity-100' : 'opacity-70'}`} style={{ color: getMarkerColor(location.type) }}></div>
                  
                  {/* Label that appears on hover or selection */}
                  <div className={`absolute -bottom-8 left-1/2 transform -translate-x-1/2 bg-white px-2 py-1 rounded shadow text-xs whitespace-nowrap ${isSelected ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`}>
                    {location.name}
                  </div>
                </div>
              );
            })}
            
            {/* Selected location info */}
            {selectedLocationData && (
              <div className="absolute bottom-4 left-4 right-4 bg-white p-4 rounded-lg shadow-lg">
                <div className="flex items-start">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center mr-3 ${getMarkerBgColor(selectedLocationData.type)}`}>
                    <span className="text-white text-lg font-bold">{selectedLocationData.name.charAt(0)}</span>
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-lg">{selectedLocationData.name}</h3>
                    <div className="flex items-center text-sm text-gray-600 mb-2">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
                      </svg>
                      <span>2.3 miles away • </span>
                      <span className="flex items-center ml-1">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-gray-300" viewBox="0 0 20 20" fill="currentColor">
                          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
                        <span className="ml-1">4.2</span>
                      </span>
                    </div>
                    <p className="text-sm text-gray-700 mb-3">
                      Professional {selectedLocationData.type} with 10+ years of experience. Specializing in residential and commercial projects.
                    </p>
                    <div className="flex gap-2">
                      <Button size="sm" variant="primary">View Details</Button>
                      <Button size="sm" variant="outline">Contact</Button>
                      <Button size="sm" variant="outline" className="ml-auto">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clipRule="evenodd" />
                        </svg>
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            {/* Controls overlay */}
            <div className="absolute top-4 right-4 bg-white p-2 rounded-lg shadow">
              <div className="flex flex-col gap-2">
                <button className="w-8 h-8 bg-white rounded-full shadow flex items-center justify-center hover:bg-gray-100">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clipRule="evenodd" />
                  </svg>
                </button>
                <button className="w-8 h-8 bg-white rounded-full shadow flex items-center justify-center hover:bg-gray-100">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M5 10a1 1 0 011-1h8a1 1 0 110 2H6a1 1 0 01-1-1z" clipRule="evenodd" />
                  </svg>
                </button>
              </div>
            </div>
            
            {/* Search box */}
            <div className="absolute top-4 left-4 right-20 max-w-md">
              <div className="relative">
                <input 
                  type="text" 
                  placeholder="Search for services or locations..." 
                  className="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-300 shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-400" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clipRule="evenodd" />
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-gray-50 p-4 rounded-lg shadow">
            <h3 className="font-bold text-lg mb-2">Filter by Service</h3>
            <div className="flex flex-wrap gap-2">
              {Array.from(new Set(mapLocations.map(loc => loc.type))).map(type => (
                <Button 
                  key={type} 
                  size="sm" 
                  variant={activeFilter === type ? "primary" : "outline"}
                  className="text-xs"
                  onClick={() => handleFilterClick(type)}
                >
                  {type.charAt(0).toUpperCase() + type.slice(1)}
                </Button>
              ))}
            </div>
            
            <div className="mt-4">
              <h4 className="font-medium text-sm mb-2">Additional Filters</h4>
              <div className="space-y-2">
                <div className="flex items-center">
                  <input id="rating" type="checkbox" className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded" />
                  <label htmlFor="rating" className="ml-2 block text-sm text-gray-700">4+ Star Rating</label>
                </div>
                <div className="flex items-center">
                  <input id="verified" type="checkbox" className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded" />
                  <label htmlFor="verified" className="ml-2 block text-sm text-gray-700">Verified Providers</label>
                </div>
                <div className="flex items-center">
                  <input id="available" type="checkbox" className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded" />
                  <label htmlFor="available" className="ml-2 block text-sm text-gray-700">Available Today</label>
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-gray-50 p-4 rounded-lg shadow">
            <h3 className="font-bold text-lg mb-2">Search Radius</h3>
            <input 
              type="range" 
              min="1" 
              max="20" 
              value={searchRadius}
              onChange={(e) => setSearchRadius(parseInt(e.target.value))}
              className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
            />
            <div className="flex justify-between text-sm text-gray-600 mt-1">
              <span>1 mile</span>
              <span>{searchRadius} miles</span>
              <span>20 miles</span>
            </div>
            
            <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-100">
              <h4 className="font-medium text-sm mb-2 text-blue-800">Service Coverage</h4>
              <p className="text-xs text-blue-700">
                There are <span className="font-bold">{filteredLocations.length}</span> service providers within {searchRadius} miles of your location.
              </p>
              <div className="mt-2 h-2 bg-gray-200 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-blue-500 rounded-full" 
                  style={{ width: `${Math.min((filteredLocations.length / mapLocations.length) * 100, 100)}%` }}
                ></div>
              </div>
            </div>
          </div>
          
          <div className="bg-gray-50 p-4 rounded-lg shadow">
            <h3 className="font-bold text-lg mb-2">Your Location</h3>
            <div className="mb-4">
              <input 
                type="text" 
                placeholder="Enter your postcode" 
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <Button 
              variant="primary" 
              fullWidth 
              className="flex items-center justify-center gap-2 mb-3"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
              </svg>
              Use Current Location
            </Button>
            
            <div className="text-xs text-gray-500 mt-2">
              <p className="mb-1">Recently searched:</p>
              <div className="flex flex-wrap gap-1">
                <span className="px-2 py-1 bg-gray-200 rounded-full hover:bg-gray-300 cursor-pointer">SW1A 1AA</span>
                <span className="px-2 py-1 bg-gray-200 rounded-full hover:bg-gray-300 cursor-pointer">E14 5AB</span>
                <span className="px-2 py-1 bg-gray-200 rounded-full hover:bg-gray-300 cursor-pointer">M1 1AE</span>
              </div>
            </div>
          </div>
        </div>
        
        {/* Recent searches and popular services */}
        <div className="mt-8">
          <h3 className="font-bold text-xl mb-4">Popular Services Near You</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {mapLocations.slice(0, 4).map(location => (
              <div key={location.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
                <div className={`h-2 ${getMarkerBgColor(location.type)}`}></div>
                <div className="p-4">
                  <h4 className="font-bold text-lg mb-1">{location.name}</h4>
                  <div className="flex items-center text-sm text-gray-600 mb-2">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
                    </svg>
                    <span>{(Math.random() * 5).toFixed(1)} miles away</span>
                  </div>
                  <p className="text-sm text-gray-700 mb-3">
                    Professional {location.type} with excellent customer ratings and competitive pricing.
                  </p>
                  <Button size="sm" variant="outline" fullWidth>View Profile</Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

// Helper function to determine marker background color based on service type
function getMarkerBgColor(type: string): string {
  const colorMap: Record<string, string> = {
    builders: 'bg-red-500',
    carpenters: 'bg-blue-500',
    electricians: 'bg-yellow-500',
    plumbers: 'bg-green-500',
    roofers: 'bg-purple-500',
    landscapers: 'bg-orange-500'
  };
  
  return colorMap[type.toLowerCase()] || 'bg-red-500';
}

// Helper function to get marker color without the bg- prefix
function getMarkerColor(type: string): string {
  const colorMap: Record<string, string> = {
    builders: '#ef4444',
    carpenters: '#3b82f6',
    electricians: '#eab308',
    plumbers: '#22c55e',
    roofers: '#a855f7',
    landscapers: '#f97316'
  };
  
  return colorMap[type.toLowerCase()] || '#ef4444';
}

export default MapPreview;
