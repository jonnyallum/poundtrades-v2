import React from 'react';
import { Star } from 'lucide-react';

const testimonials = [
  {
    name: 'John Smith',
    role: 'Building Contractor',
    content: 'PoundTrades has saved me thousands on building materials. I found exactly what I needed for my renovation project at a fraction of the retail price.',
    rating: 5
  },
  {
    name: 'Sarah Johnson',
    role: 'DIY Enthusiast',
    content: 'As a home DIYer, I was struggling to find affordable materials. PoundTrades connected me with sellers who had exactly what I needed. The £1 fee is so worth it!',
    rating: 5
  },
  {
    name: 'Mike Williams',
    role: 'Construction Manager',
    content: 'We had excess materials from a large project and listed them on PoundTrades. They sold quickly and we recovered some of our costs. Great platform!',
    rating: 4
  }
];

const Testimonials: React.FC = () => {
  return (
    <section className="py-16 bg-gray-950">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-white mb-2">What Our Users Say</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Join thousands of satisfied users who have found great deals on building materials
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div 
              key={index} 
              className="bg-gray-900 border border-gray-800 rounded-lg p-6 transition-all duration-300 hover:border-gold-500"
            >
              <div className="flex mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star 
                    key={i} 
                    size={18} 
                    className={i < testimonial.rating ? "text-gold-500 fill-gold-500" : "text-gray-600"} 
                  />
                ))}
              </div>
              <p className="text-gray-300 mb-6 italic">"{testimonial.content}"</p>
              <div className="flex items-center">
                <div className="w-10 h-10 rounded-full bg-gold-500 flex items-center justify-center text-black font-bold">
                  {testimonial.name.charAt(0)}
                </div>
                <div className="ml-3">
                  <h4 className="text-white font-medium">{testimonial.name}</h4>
                  <p className="text-gray-400 text-sm">{testimonial.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
