import React from 'react';
import Button from '../ui/Button';

const MapFallback: React.FC = () => {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Find Services Near You</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Browse local services and tradespeople in your area. Our interactive map helps you find the perfect service provider nearby.
          </p>
        </div>
        
        <div className="bg-gray-100 rounded-lg h-[400px] flex flex-col items-center justify-center shadow-inner">
          <div className="mb-4">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />
            </svg>
          </div>
          <p className="text-gray-600 mb-4">Interactive map experience</p>
          <Button variant="primary">Enable Location Services</Button>
        </div>

        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-gray-50 p-4 rounded-lg shadow">
            <h3 className="font-bold text-lg mb-2">Popular Areas</h3>
            <ul className="space-y-2">
              <li className="flex items-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-[#f7d046]" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
                </svg>
                <span>Central London</span>
              </li>
              <li className="flex items-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-[#f7d046]" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
                </svg>
                <span>Manchester</span>
              </li>
              <li className="flex items-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-[#f7d046]" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
                </svg>
                <span>Birmingham</span>
              </li>
            </ul>
          </div>
          
          <div className="bg-gray-50 p-4 rounded-lg shadow">
            <h3 className="font-bold text-lg mb-2">Service Availability</h3>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span>Builders</span>
                <span className="text-green-600 font-medium">High</span>
              </div>
              <div className="flex justify-between items-center">
                <span>Electricians</span>
                <span className="text-yellow-600 font-medium">Medium</span>
              </div>
              <div className="flex justify-between items-center">
                <span>Plumbers</span>
                <span className="text-green-600 font-medium">High</span>
              </div>
            </div>
          </div>
          
          <div className="bg-gray-50 p-4 rounded-lg shadow">
            <h3 className="font-bold text-lg mb-2">Search by Postcode</h3>
            <div className="flex gap-2">
              <input 
                type="text" 
                placeholder="Enter postcode" 
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#f7d046] focus:border-transparent"
              />
              <Button variant="primary">Search</Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default MapFallback;
