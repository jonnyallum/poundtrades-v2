import React from 'react';
import Button from '../ui/Button';

const CTA: React.FC = () => {
  return (
    <section className="bg-[#1a1a1a] text-white py-16">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Trade Your Surplus Materials?</h2>
          <p className="text-lg mb-8 text-gray-300">Join PoundTrades today and turn your excess building materials into profit while helping others save on their projects.</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button variant="primary" size="lg">Sign Up Now</Button>
            <Button variant="outline" size="lg" className="border-white text-white hover:bg-white hover:text-[#1a1a1a]">Learn More</Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTA;
