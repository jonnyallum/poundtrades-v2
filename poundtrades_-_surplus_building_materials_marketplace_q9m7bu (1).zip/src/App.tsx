import React, { Suspense, lazy } from 'react';
import Header from './components/layout/Header';
import Footer from './components/layout/Footer';
import Hero from './components/home/Hero';
import Categories from './components/home/Categories';
import Services from './components/home/Services';
import Features from './components/home/Features';
import Testimonials from './components/home/Testimonials';
import CTA from './components/home/CTA';
import MapFallback from './components/home/MapFallback';
import MapPreview from './components/home/MapPreview';

// Lazy load the Map component since it contains heavy dependencies
const Map = lazy(() => import('./components/home/Map'));

function App() {
  // Set to true to show the static preview instead of the actual Google Maps component
  const showStaticPreview = true;

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow">
        <Hero />
        <Categories />
        <Services />
        <Features />
        {showStaticPreview ? (
          <MapPreview />
        ) : (
          <Suspense fallback={<MapFallback />}>
            <Map />
          </Suspense>
        )}
        <Testimonials />
        <CTA />
      </main>
      <Footer />
    </div>
  );
}

export default App;
