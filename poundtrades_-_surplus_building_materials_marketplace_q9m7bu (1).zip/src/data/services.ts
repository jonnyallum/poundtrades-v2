import { Service } from '../types';

export const services: Service[] = [
  {
    id: '1',
    name: 'Builders',
    icon: 'hard-hat',
    description: 'Find surplus materials for your building projects',
    location: {
      lat: 51.505,
      lng: -0.09
    }
  },
  {
    id: '2',
    name: 'Carpenters',
    icon: 'hammer',
    description: 'Discover quality timber and wood products at reduced prices',
    location: {
      lat: 51.51,
      lng: -0.1
    }
  },
  {
    id: '3',
    name: 'Electricians',
    icon: 'zap',
    description: 'Source electrical components and supplies from local projects',
    location: {
      lat: 51.515,
      lng: -0.08
    }
  },
  {
    id: '4',
    name: 'Plumbers',
    icon: 'wrench',
    description: 'Access plumbing materials and fixtures at significant savings',
    location: {
      lat: 51.52,
      lng: -0.095
    }
  },
  {
    id: '5',
    name: 'Roofers',
    icon: 'home',
    description: 'Find roofing materials from completed or changed projects',
    location: {
      lat: 51.5,
      lng: -0.085
    }
  },
  {
    id: '6',
    name: 'Landscapers',
    icon: 'palmtree',
    description: 'Source materials for outdoor and garden construction',
    location: {
      lat: 51.508,
      lng: -0.11
    }
  }
];

export const mapLocations = services.map(service => ({
  id: service.id,
  name: service.name,
  type: service.name.toLowerCase(),
  location: service.location || { lat: 51.505, lng: -0.09 }
}));
