import { Category } from '../types';

export const categories: Category[] = [
  {
    id: '1',
    name: 'Timber & Wood Products',
    icon: 'tree',
    description: 'Surplus timber, plywood, MDF and other wood materials'
  },
  {
    id: '2',
    name: 'Bricks & Blocks',
    icon: 'square',
    description: 'Leftover bricks, blocks, and masonry materials'
  },
  {
    id: '3',
    name: 'Insulation',
    icon: 'layers',
    description: 'Excess insulation materials for walls, roofs and floors'
  },
  {
    id: '4',
    name: 'Plumbing',
    icon: 'pipe',
    description: 'Surplus pipes, fittings and plumbing supplies'
  },
  {
    id: '5',
    name: 'Electrical',
    icon: 'zap',
    description: 'Extra electrical cables, fixtures and components'
  },
  {
    id: '6',
    name: 'Doors & Windows',
    icon: 'door',
    description: 'Unused doors, windows and related hardware'
  },
  {
    id: '7',
    name: 'Roofing',
    icon: 'home',
    description: 'Surplus roofing tiles, felt and materials'
  },
  {
    id: '8',
    name: 'Tools & Equipment',
    icon: 'tool',
    description: 'Used or new tools and construction equipment'
  }
];
